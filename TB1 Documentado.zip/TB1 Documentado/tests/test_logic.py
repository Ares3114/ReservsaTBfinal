
import unittest
from datetime import datetime, date, timedelta

from models import Customer, LoyaltyRule, LoyaltyTier, Reservation
from repositories import VisitRepository, InMemoryCustomerRepository
from strategies import VisitsInWindowStrategy
from engine import LoyaltyEngine

class FakeRepo(VisitRepository):
    def __init__(self, reservations):
        self._res = reservations
    def get_reservations(self):
        return self._res

class TestLoyalty(unittest.TestCase):
    def setUp(self):
        self.c = Customer(id="C1", name="Ana", email="a@a", phone="1")
        today = date(2025,9,20)
        self.today = today
        # 3 visitas dentro de ventana 3m, 1 fuera
        self.res = [
            Reservation(id="R1", customer_id="C1", dt=datetime(2025,9,1,20,0), party_size=2),
            Reservation(id="R2", customer_id="C1", dt=datetime(2025,8,10,20,0), party_size=2),
            Reservation(id="R3", customer_id="C1", dt=datetime(2025,6,25,20,0), party_size=2),
            Reservation(id="R4", customer_id="C1", dt=datetime(2025,5,10,20,0), party_size=2), # fuera
        ]
        self.repo = FakeRepo(self.res)
        self.customers = InMemoryCustomerRepository({"C1": self.c})

    def test_vip_thresholds(self):
        rules = [
            LoyaltyRule(min_visits=4, window_months=3, resulting_tier=LoyaltyTier("Super VIP", 2)),
            LoyaltyRule(min_visits=2, window_months=3, resulting_tier=LoyaltyTier("VIP", 1)),
        ]
        strat = VisitsInWindowStrategy(rules_desc=rules, window_months=3, unique_per_day=True)
        eng = LoyaltyEngine(strategy=strat, repo=self.repo, customers=self.customers)
        tier = eng.classify(self.c, self.today)
        self.assertEqual(tier.name, "VIP")

    def test_regular_when_low(self):
        rules = [
            LoyaltyRule(min_visits=5, window_months=3, resulting_tier=LoyaltyTier("Super VIP", 2)),
            LoyaltyRule(min_visits=4, window_months=3, resulting_tier=LoyaltyTier("VIP", 1)),
        ]
        strat = VisitsInWindowStrategy(rules_desc=rules, window_months=3, unique_per_day=True)
        eng = LoyaltyEngine(strategy=strat, repo=self.repo, customers=self.customers)
        tier = eng.classify(self.c, self.today)
        self.assertEqual(tier.name, "Regular")

if __name__ == "__main__":
    unittest.main()
